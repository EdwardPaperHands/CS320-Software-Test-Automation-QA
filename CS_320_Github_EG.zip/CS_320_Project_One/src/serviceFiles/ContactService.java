/*Eduardo Gonzalez
 * CS320 Project One Milestone
*/
package serviceFiles;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>(); // hashmap created to keep map of updateable contacts 

    public void addContact(Contact contact) { // add contact to hashmap
        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactID(), contact);
    }

    public void deleteContact(String contactID) { // delete contact from hashmap
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contactID);
    }

    public void updateFirstName(String contactID, String firstName) { // update contact firstName from hashmap
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.get(contactID).setFirstName(firstName);
    }

    public void updateLastName(String contactID, String lastName) { // update contact lastName from hashmap
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.get(contactID).setLastName(lastName);
    }

    public void updatePhone(String contactID, String phone) { //update contacts phone number
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.get(contactID).setPhone(phone);
    }

    public void updateAddress(String contactID, String address) { // update contacts address
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.get(contactID).setAddress(address);
    }

    public Contact getContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        return contacts.get(contactID);
    }
}